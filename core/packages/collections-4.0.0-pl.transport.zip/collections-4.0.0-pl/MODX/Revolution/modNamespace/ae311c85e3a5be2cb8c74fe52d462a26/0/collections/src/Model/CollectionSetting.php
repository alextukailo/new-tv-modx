<?php
namespace Collections\Model;

use xPDO\xPDO;

/**
 * Class CollectionSetting
 *
 * @property integer $collection
 * @property integer $template
 *
 * @package Collections\Model
 */
class CollectionSetting extends \xPDO\Om\xPDOSimpleObject
{
}
